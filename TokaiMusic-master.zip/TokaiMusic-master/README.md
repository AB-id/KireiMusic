<h1 align="centre">Tokai Music</h1>

### Bot Untuk Download Dan Memutar Musik Di VCG

### Forker [Tokai](https://t.me/Insaynn)

# Find Me On [Telegram](https://t.me/TokaiMusicBot)

<p align="center">
  <img src="https://telegra.ph/file/7d7eaba0a5e8c504b1a29.jpg">
</p>

<h2> Update 🔥 </h2>

- Thumbnail Support
- Playlist Support
- Current playback support
- Showing track names when skipping
- Zero downtime, Fully Stable
- DEEZER,YOUTUBE & SAAVN PLAYBACK SUPPORTED
- Settings panel
- Control with buttons
- Userbot auto join

### Commands 🛠
#### Untuk Semua Member.

- `/play <song name>` - play song you requested
- `/dplay <song name>` - play song you requested via deezer
- `/splay <song name>` - play song you requested via jio saavn
- `/playlist` - Show now playing list
- `/current` - Show now playing
- `/song <song name>` - download songs you want quickly
- `/search <query>` - search videos on youtube with details
- `/deezer <song name>` - download songs you want quickly via deezer
- `/saavn <song name>` - download songs you want quickly via saavn
- `/video <song name>` - download videos you want quickly

#### Hanya Admin.
- `/player` - open music player settings panel
- `/pause` - pause song play
- `/resume` - resume song play
- `/skip` - play next song
- `/end` - stop music play
- `/userbotjoin` - invite assistant to your chat
- `/userbotleave` - remove assistant from your chat
- `/admincache` - Refresh admin list


### Deploy To Heroku</h4>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Tokai-Robo/TokaiMusic)

Use [@DaisyXStringGeneratorBot](https://t.me/DaisyXStringGeneratorBot) to get pyrogram string session or [repl](https://repl.it/@SpEcHiDe/GenerateStringSession)

### Semua Credits
- [InukaASiTH](https://github.com/InukaAsith): Dev
- [Wrench](https://github.com/EverythingSuckz/): Dev
- [QueenArzoo](https://github.com/QueenArzoo): Dev
- [lucifeermorningstar](https://github.com/lucifeermorningstar): Dev
- [AuraXNetwork](https://github.com/AuraXNetwork/AuraXMusicBot)
- [Hamker Cat](https://github.com/thehamkercat/)
- [Anjana-Ma](https://github.com/Anjana-Ma): 
- [ImJanindu](https://github.com/ImJanindu): 
- [Laky](https://github.com/Laky-64) & [Andrew](https://github.com/AndrewLaneX): PyTgCalls
- [Original Repo owners](https://github.com/suprojects/CallsMusic)
